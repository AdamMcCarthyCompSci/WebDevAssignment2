var xmlhttp = new XMLHttpRequest();
var url = "scheduling.json";

xmlhttp.onreadystatechange = function () {
  if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
    //Parse the JSON data to a JavaScript variable.
    var parsedObj = JSON.parse(xmlhttp.responseText);
    // This function is defined below and deals with the JSON data read from the file.
    mainFunction(parsedObj);
  }
};

xmlhttp.open("GET", url, true);
xmlhttp.send();

function mainFunction(obj) {
  const dayContainer = document.getElementById("dayContainer");
  const submitButton = document.getElementById("submitButton");
  obj.forEach(function (item) {
    submitButton.style.display = "none";
    const dayButton = document.createElement("button");
    dayButton.innerHTML = item.day;
    dayButton.className = "dayClass";
    var slot = item.slots;
    dayButton.onclick = function () {
      submitButton.style.backgroundColor = "slategray";
      sessionContainer.style.display = "none";
      window.fullDay = slot;
      dayFunction(slot, this);
      paperFunction();
      if (window.paperToggle == undefined) {
        window.paperToggle = "All";
      }
    };
    dayContainer.append(dayButton);
  });
}

function dayFunction(obj, click) {
  var dayLoop = document.getElementsByClassName("dayClass");
  for (var i = 0; i < dayLoop.length; i++) {
    if (dayLoop[i] === click) {
      click.style.backgroundColor = "cadetblue";
    } else {
      dayLoop[i].style.backgroundColor = "lightslategray";
    }
  }
  const timeContainer = document.getElementById("timeContainer");
  const sessionContainer = document.getElementById("sessionContainer");
  const paperContainer = document.getElementById("paperContainer");
  emptyContainer(paperContainer);
  emptyContainer(sessionContainer);
  emptyContainer(timeContainer);
  for (var i in obj) {
    const timeButton = document.createElement("button");
    timeButton.innerHTML = obj[i].time;
    timeButton.id = i;
    timeButton.className = "timeClass";
    timeButton.onclick = function () {
      submitButton.style.backgroundColor = "slategray";
      sessionContainer.style.display = "none";
      timeFunction(obj, this, window.paperToggle);
    };
    timeContainer.append(timeButton);
  }
}

function timeFunction(obj, click) {
  var timeLoop = document.getElementsByClassName("timeClass");
  for (var i = 0; i < timeLoop.length; i++) {
    if (timeLoop[i] === click) {
      click.style.backgroundColor =
        click.style.backgroundColor === "cadetblue"
          ? "lightslategray"
          : "cadetblue";
    } else {
      timeLoop[i].style.backgroundColor = "lightslategray";
    }
  }
  var session = obj[click.id].sessions;
  const sessionContainer = document.getElementById("sessionContainer");
  emptyContainer(sessionContainer);
  sessionContainer.innerHTML += "<h3 id='noSessions'>Sessions:</h3>";
  sessionFunction(session);
}

function paperFunction() {
  const paperContainer = document.getElementById("paperContainer");
  const paperButton1 = document.createElement("button");
  const submitButton = document.getElementById("submitButton");
  paperButton1.innerHTML = "All Sessions";
  paperButton1.className = "paperClass";
  submitButton.style.display = "block";
  paperButton1.style.backgroundColor = "cadetblue";
  window.paperToggle = undefined;
  paperButton1.onclick = function () {
    sessionContainer.style.display = "none";
    window.paperToggle = "All";
    paperButton1.style.backgroundColor = "cadetblue";
    paperButton2.style.backgroundColor = "lightslategray";
    paperButton3.style.backgroundColor = "lightslategray";
    submitButton.style.backgroundColor = "slategray";
    timeButtonColour("lightslategray");
    emptyContainer(sessionContainer);
  };
  paperContainer.append(paperButton1);

  const paperButton2 = document.createElement("button");
  paperButton2.innerHTML = "Only Paper Sessions";
  paperButton2.className = "paperClass";
  paperButton2.style.backgroundColor = "lightslategray";
  paperButton2.onclick = function () {
    sessionContainer.style.display = "none";
    window.paperToggle = "Paper";
    paperButton1.style.backgroundColor = "lightslategray";
    paperButton2.style.backgroundColor = "cadetblue";
    paperButton3.style.backgroundColor = "lightslategray";
    submitButton.style.backgroundColor = "slategray";
    timeButtonColour("lightslategray");
    emptyContainer(sessionContainer);
  };
  paperContainer.append(paperButton2);

  const paperButton3 = document.createElement("button");
  paperButton3.innerHTML = "Only Non-Paper Sessions";
  paperButton3.className = "paperClass";
  paperButton3.style.backgroundColor = "lightslategray";
  paperButton3.onclick = function () {
    submitButton.style.backgroundColor = "slategray";
    sessionContainer.style.display = "none";
    window.paperToggle = "Other";
    paperButton1.style.backgroundColor = "lightslategray";
    paperButton2.style.backgroundColor = "lightslategray";
    paperButton3.style.backgroundColor = "cadetblue";
    timeButtonColour("lightslategray");
    emptyContainer(sessionContainer);
  };
  paperContainer.append(paperButton3);
}

function emptyContainer(cont) {
  while (cont.hasChildNodes()) {
    cont.removeChild(cont.lastChild);
  }
}

function timeButtonColour(colour) {
  var timeLoop = document.getElementsByClassName("timeClass");
  for (var i = 0; i < timeLoop.length; i++) {
    timeLoop[i].style.backgroundColor = colour;
  }
}

function sessionFunction(obj) {
  obj.forEach(function (item) {
    const sessionButton = document.createElement("button");
    sessionButton.innerHTML =
      item.title +
      "</br>" +
      item.time +
      "</br>" +
      item.room +
      "</br>" +
      item.type;
    sessionButton.className = "sessionClass";
    var modal = document.getElementById("myModal");
    var span = document.getElementsByClassName("close")[0];
    sessionButton.onclick = function () {
      emptyContainer(submissionsList);
      var submission = item.submissions;
      modal.style.display = "block";
      submission.forEach(function (item) {
        var title = item.title;
        var submissionLink = document.createElement("a");
        var submissionText = document.createTextNode(title);
        submissionLink.appendChild(submissionText);
        submissionLink.title = "item.title";
        submissionLink.href = item.doiUrl;
        submissionsList.append(submissionLink);
        submissionsList.innerHTML += "</br></br>";
      });
      if (submissionsList.innerHTML === "") {
        submissionsList.innerHTML +=
          "<p id=emptyModal> No submissions available.</p>";
      }
    };
    span.onclick = function () {
      modal.style.display = "none";
    };
    window.onclick = function (event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    };
    if (window.paperToggle == "All") {
      sessionContainer.append(sessionButton);
    }
    if (window.paperToggle == "Paper" && item.type == "paper") {
      sessionContainer.append(sessionButton);
    }
    if (window.paperToggle == "Other" && item.type != "paper") {
      sessionContainer.append(sessionButton);
    }
  });
}

function submitFunction() {
  submitButton.style.backgroundColor = "cadetblue";
  sessionContainer.style.display = "grid";
  var timeSelect = 0;
  var timeLoop = document.getElementsByClassName("timeClass");
  for (var i = 0; i < timeLoop.length; i++) {
    if (timeLoop[i].style.backgroundColor == "cadetblue") {
      timeSelect++;
    }
  }
  if (timeSelect == 0) {
    const sessionContainer = document.getElementById("sessionContainer");
    emptyContainer(sessionContainer);
    sessionContainer.innerHTML += "<h3 id='noSessions'>Sessions:</h3>";
    timeButtonColour("cadetblue");
    for (var i in window.fullDay) {
      var session = fullDay[i].sessions;
      sessionFunction(session);
    }
  }
}
